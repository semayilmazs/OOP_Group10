var searchData=
[
  ['reducestock_0',['reduceStock',['../class_product.html#a6e58c5b271636e03fe4fc294cfab354f',1,'Product']]]
];
