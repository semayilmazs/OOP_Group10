var searchData=
[
  ['password_0',['password',['../class_user.html#ac887622f22a898c097d156ad964be846',1,'User']]],
  ['product_1',['Product',['../class_product.html',1,'Product'],['../class_product.html#a2a5ab4c0eb363312e147a04e4de6e35a',1,'Product::Product()']]]
];
