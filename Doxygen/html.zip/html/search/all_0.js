var searchData=
[
  ['addproduct_0',['addProduct',['../class_order.html#a7647bb00785be5e4ed1971fa34b51287',1,'Order']]],
  ['addtoorderhistory_1',['addToOrderHistory',['../class_customer.html#a9c2cb848aa3e2d84767ecdf3be120c92',1,'Customer']]]
];
