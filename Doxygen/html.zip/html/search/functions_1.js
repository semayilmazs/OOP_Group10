var searchData=
[
  ['confirmorder_0',['confirmOrder',['../class_order.html#ace0a59d1e9ec42a028d67706336c1268',1,'Order']]],
  ['customer_1',['Customer',['../class_customer.html#aff205cbade0bc9c9e6cf3caec0568e5b',1,'Customer']]]
];
