var searchData=
[
  ['userid_0',['userID',['../class_user.html#a2763d16d115f2a3be14689c378b434c8',1,'User']]],
  ['username_1',['username',['../class_user.html#ae4202de2b7974e92a55b913d20b03833',1,'User']]]
];
