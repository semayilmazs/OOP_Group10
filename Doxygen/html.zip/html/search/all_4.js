var searchData=
[
  ['increasestock_0',['increaseStock',['../class_product.html#ac2429b2f060d5e9d9f2439db73e82402',1,'Product']]]
];
