var searchData=
[
  ['verification_0',['verification',['../class_user.html#a62dc90ee8b07ea5cf7bb18cb89d7f1c0',1,'User']]]
];
