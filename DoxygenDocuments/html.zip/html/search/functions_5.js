var searchData=
[
  ['verification_0',['verification',['../class_user.html#a1083d4187ea0f38005422a1a4c946067',1,'User']]]
];
