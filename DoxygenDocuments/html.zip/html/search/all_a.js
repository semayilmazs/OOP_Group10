var searchData=
[
  ['user_0',['User',['../class_user.html',1,'User'],['../class_user.html#a0852f1aa694f08366f9797fe2984685d',1,'User::User()']]]
];
