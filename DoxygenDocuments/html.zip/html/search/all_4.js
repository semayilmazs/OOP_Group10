var searchData=
[
  ['mainwindow_0',['MainWindow',['../class_main_window.html',1,'']]],
  ['members_3a_1',['Group members:',['../index.html#autotoc_md1',1,'']]]
];
